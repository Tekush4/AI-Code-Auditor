import { openDatabase } from "./modules/db/database.ts";
import { createServer } from "./modules/http/server.ts";
const dbPath=process.env.AICA_DB_PATH ?? "./ai-code-auditor.sqlite";
const port=Number(process.env.PORT ?? 3000);
const server=createServer(openDatabase(dbPath));
// Escuta em 0.0.0.0 explicitamente (necessário em containers/PaaS como Render,
// que fazem healthcheck via IP da interface, não só via localhost).
server.listen(port,"0.0.0.0",()=>console.log(`AI Code Auditor API listening on http://0.0.0.0:${port}`));
