import { readFileSync } from "node:fs";
import path from "node:path";
import type { ImportedFile } from "../../import/localImporter.ts";
export interface ArchitectureNode { id:string; type:"module"|"component"|"api"|"database"|"container"|"service"; label:string; }
export interface ArchitectureRelationship { from:string; to:string; kind:"imports"|"contains"|"calls"|"depends_on"; }
export interface ArchitectureReport { languages:string[]; frameworks:string[]; modules:string[]; dependencies:string[]; components:ArchitectureNode[]; relationships:ArchitectureRelationship[]; cycles:string[][]; risks:string[]; limitations:string[]; }
const CODE_EXT=new Set([".js",".jsx",".ts",".tsx",".mjs",".cjs",".py"]);
const id=(p:string)=>`module:${p.replaceAll("\\","/")}`;
function imports(code:string){return [...code.matchAll(/(?:import\s+(?:[^;]*?\s+from\s+)?|require\s*\(|from\s+)["']([^"']+)["']/g)].map(m=>m[1]);}
function resolve(from:string,spec:string,files:Set<string>){if(!spec.startsWith("."))return null;const b=path.posix.normalize(path.posix.join(path.posix.dirname(from),spec));const cs=[b,...[".ts",".tsx",".js",".jsx",".py"].map(x=>b+x),... ["index.ts","index.js","__init__.py"].map(x=>path.posix.join(b,x))];return cs.find(x=>files.has(x))??null;}
function cycles(edges:Map<string,string[]>){const out:string[][]=[],active=new Set<string>(),done=new Set<string>();function dfs(n:string,stack:string[]){if(active.has(n)){const i=stack.indexOf(n);if(i>=0)out.push([...stack.slice(i),n]);return;}if(done.has(n))return;active.add(n);for(const x of edges.get(n)??[])dfs(x,[...stack,n]);active.delete(n);done.add(n);}for(const n of edges.keys())dfs(n,[]);return out;}
export function analyzeArchitecture(baseDir:string,imported:ImportedFile[]):ArchitectureReport{
 const files=new Set(imported.map(f=>f.relativePath.replaceAll("\\","/"))), contents=new Map<string,string>();
 for(const f of imported){if(!CODE_EXT.has(path.extname(f.relativePath).toLowerCase())||f.sizeBytes>2_000_000)continue;try{contents.set(f.relativePath.replaceAll("\\","/"),readFileSync(path.join(baseDir,f.relativePath),"utf8"));}catch{}}
 const languages=[...new Set([...contents.keys()].map(f=>path.extname(f).toLowerCase()).map(e=>e.includes("ts")?"TypeScript":e.includes("js")?"JavaScript":e===".py"?"Python":e.slice(1)))];
 const modules=[...contents.keys()],deps=new Set<string>(),relationships:ArchitectureRelationship[]=[],edges=new Map<string,string[]>();
 for(const [file,code] of contents){const from=id(file);edges.set(from,[]);for(const spec of imports(code)){if(!spec.startsWith(".")){deps.add(spec.split("/")[0]);continue;}const t=resolve(file,spec,files);if(t){const to=id(t);edges.get(from)!.push(to);relationships.push({from,to,kind:"imports"});}}}
 const all=[...contents.values()].join("\n"),frameworks:string[]=[];for(const [n,re] of [["React",/from ['"]react['"]/],["Express",/express/],["Fastify",/fastify/],["NestJS",/@nestjs\//],["Django",/from django\./],["Flask",/from flask import/]] as const)if(re.test(all))frameworks.push(n);
 const cs=cycles(edges),risks:string[]=[];if(cs.length)risks.push(`${cs.length} ciclo(s) de dependência detectado(s).`);for(const [n,ns] of edges)if(ns.length>=10)risks.push(`Módulo excessivamente dependente: ${n.replace("module:","")} (${ns.length} imports locais).`);for(const [f,c] of contents)if(c.split("\n").length>800)risks.push(`Arquivo muito grande: ${f}.`);
 return {languages,frameworks,modules,dependencies:[...deps].sort(),components:modules.map(f=>({id:id(f),type:"module",label:f})),relationships,cycles:cs,risks,limitations:["Imports dinâmicos, aliases de bundler e reflexão podem não ser resolvidos.","Arquivos binários e arquivos acima de 2 MB foram omitidos da leitura."]};
}
