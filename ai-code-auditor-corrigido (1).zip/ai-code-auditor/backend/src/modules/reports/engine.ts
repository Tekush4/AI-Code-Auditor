/**
 * Report Engine — Fase 15.
 *
 * Consome a saída do Correlation Engine + Risk Engine e gera relatórios em
 * JSON (para consumo por outra ferramenta) e Markdown (para leitura humana).
 * Formato HTML fica para uma próxima fase, junto com o frontend (Fase 16),
 * para reaproveitar componentes de apresentação em vez de duplicar em string.
 */
import type { Finding } from "../findings/model.ts";
import type { ProjectRiskSummary } from "../risk/engine.ts";

export interface ReportInput {
  projectName: string;
  generatedAt: string; // ISO 8601
  findings: Finding[];
  risk: ProjectRiskSummary;
}

export function buildJsonReport(input: ReportInput): string {
  return JSON.stringify(
    {
      project: input.projectName,
      generatedAt: input.generatedAt,
      summary: {
        overallScore: input.risk.overallScore,
        totalFindings: input.risk.totalFindings,
        bySeverity: input.risk.bySeverity,
      },
      findings: input.findings.map(f => ({
        id: f.id,
        title: f.title,
        severity: f.severity,
        confidence: f.confidence,
        status: f.status,
        category: f.category,
        cwe: f.cwe,
        file: f.file,
        line: f.line,
        remediation: f.remediation,
        evidenceSources: f.evidence.map(e => e.source),
      })),
    },
    null,
    2
  );
}

function severityBadge(severity: Finding["severity"]): string {
  return `\`${severity}\``;
}

export function buildHtmlReport(input: ReportInput): string {
  const esc=(v:string)=>v.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
  const rows=input.findings.map(f=>`<tr><td>${esc(f.severity)}</td><td>${esc(f.title)}</td><td>${esc(f.file)}${f.line?`:${f.line}`:""}</td><td>${esc(f.confidence)}</td><td>${esc(f.remediation)}</td></tr>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>AI Code Auditor - ${esc(input.projectName)}</title><style>body{font-family:system-ui;margin:2rem}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:.5rem;text-align:left}</style></head><body><h1>Relatório — ${esc(input.projectName)}</h1><p>Score: <b>${input.risk.overallScore}/100</b></p><p>Findings ativos: ${input.risk.totalFindings}</p><table><thead><tr><th>Severidade</th><th>Finding</th><th>Arquivo</th><th>Confiança</th><th>Remediação</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
}

export function buildMarkdownReport(input: ReportInput): string {
  const lines: string[] = [];
  lines.push(`# Relatório de Segurança — ${input.projectName}`);
  lines.push("");
  lines.push(`Gerado em: ${input.generatedAt}`);
  lines.push("");
  lines.push(`**Score geral de risco:** ${input.risk.overallScore}/100`);
  lines.push("");
  lines.push("## Resumo por severidade");
  lines.push("");
  lines.push("| Severidade | Quantidade |");
  lines.push("|---|---|");
  for (const [severity, count] of Object.entries(input.risk.bySeverity)) {
    lines.push(`| ${severity} | ${count} |`);
  }
  lines.push("");
  lines.push("## Findings");
  lines.push("");

  if (input.findings.length === 0) {
    lines.push("Nenhum finding ativo neste relatório.");
  }

  for (const f of input.findings) {
    lines.push(`### ${f.title}`);
    lines.push("");
    lines.push(`- **Severidade:** ${severityBadge(f.severity)}`);
    lines.push(`- **Confiança:** ${f.confidence}`);
    lines.push(`- **Status:** ${f.status}`);
    lines.push(`- **Categoria:** ${f.category}`);
    if (f.cwe) lines.push(`- **CWE:** ${f.cwe}`);
    lines.push(`- **Arquivo:** ${f.file}${f.line ? `:${f.line}` : ""}`);
    lines.push(`- **Evidências:** ${f.evidence.map(e => e.source).join(", ")}`);
    lines.push(`- **Remediação:** ${f.remediation}`);
    lines.push("");
  }

  return lines.join("\n");
}
