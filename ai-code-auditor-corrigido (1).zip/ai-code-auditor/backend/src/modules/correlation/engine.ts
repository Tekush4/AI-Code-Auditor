/**
 * Correlation Engine — Fase 13.
 *
 * Se SAST, Secrets e Dependencies apontarem para o MESMO problema (mesmo
 * arquivo + mesma linha, quando disponível + categoria equivalente), o
 * usuário não deve ver dois findings separados — deve ver um finding com
 * duas evidências (regra 22 do prompt mestre).
 *
 * Regra de correlação (deliberadamente conservadora): dois findings só são
 * o "mesmo problema" se apontarem para o mesmo `file` E (mesma `line` OU
 * ambos sem linha) E a mesma `category`. Correlacionar por categoria diferente
 * geraria falsos agrupamentos (ex.: um secret e uma SQL injection no mesmo
 * arquivo não são o mesmo achado).
 */
import type { Finding } from "../findings/model.ts";

function groupKey(f: Finding): string {
  return `${f.file}::${f.line ?? "no-line"}::${f.category}`;
}

/** Quando dois findings se fundem, o mais severo e mais confiante vence os campos de exibição. */
const SEVERITY_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"];
const CONFIDENCE_ORDER = ["high", "medium", "low"];
const STATUS_ORDER = ["CONFIRMED", "LIKELY", "POTENTIAL", "FALSE_POSITIVE"];

function strongerOf<T extends string>(order: T[], a: T, b: T): T {
  return order.indexOf(a) <= order.indexOf(b) ? a : b;
}

export function correlateFindings(findings: Finding[]): Finding[] {
  const groups = new Map<string, Finding>();

  for (const finding of findings) {
    const key = groupKey(finding);
    const existing = groups.get(key);

    if (!existing) {
      groups.set(key, { ...finding, evidence: [...finding.evidence] });
      continue;
    }

    // Funde: mantém o id do primeiro achado (estável), soma evidências,
    // e sobe para a maior severidade/confiança/status observados.
    existing.evidence.push(...finding.evidence);
    existing.severity = strongerOf(SEVERITY_ORDER as Finding["severity"][], existing.severity, finding.severity);
    existing.confidence = strongerOf(CONFIDENCE_ORDER as Finding["confidence"][], existing.confidence, finding.confidence);
    existing.status = strongerOf(STATUS_ORDER as Finding["status"][], existing.status, finding.status);
  }

  return [...groups.values()];
}
