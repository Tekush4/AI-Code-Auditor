/**
 * SAST Engine — Fase 7.
 *
 * Usa o TypeScript Compiler API para parsear JS/TS em uma AST real (não regex).
 * O pacote `typescript` já vem instalado globalmente neste ambiente; foi
 * disponibilizado ao projeto via `node_modules/typescript` -> symlink para a
 * instalação global (ver README.md), já que não há acesso a `npm install` aqui.
 *
 * Cada regra segue o formato exigido pelo prompt mestre (seção 6):
 * ID, NAME, CATEGORY, SEVERITY, DESCRIPTION, CWE, CONFIDENCE, REMEDIATION.
 *
 * Limitação declarada: análise de fluxo de dados (taint tracking) aqui é local
 * ao AST da função — não rastreia entre arquivos/módulos. Um SAST de produção
 * complementaria isso com Semgrep (regras OWASP mantidas externamente).
 */
import ts from "typescript";
import { getSecurityRule } from "./ruleRegistry.ts";

export type Severity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO";
export type Confidence = "high" | "medium" | "low";

export interface SastFinding {
  ruleId: string;
  name: string;
  category: string;
  severity: Severity;
  cwe: string;
  confidence: Confidence;
  file: string;
  line: number;
  snippet: string;
  remediation: string;
}

function getLine(sourceFile: ts.SourceFile, node: ts.Node): number {
  return sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1;
}

function isCallTo(node: ts.Node, ...names: string[]): node is ts.CallExpression {
  if (!ts.isCallExpression(node)) return false;
  const expr = node.expression;
  if (ts.isIdentifier(expr)) return names.includes(expr.text);
  if (ts.isPropertyAccessExpression(expr)) return names.includes(expr.name.text);
  return false;
}

/** Um argumento é "dinâmico" se não for um literal de string simples (indício de dado externo). */
function isDynamicArg(node: ts.Expression): boolean {
  if (ts.isStringLiteralLike(node)) return false;
  if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.PlusToken) return true;
  if (ts.isTemplateExpression(node)) return true;
  return !ts.isStringLiteralLike(node);
}

export function analyzeSource(code: string, fileName: string): SastFinding[] {
  const findings: SastFinding[] = [];
  const sourceFile = ts.createSourceFile(fileName, code, ts.ScriptTarget.Latest, true);

  function visit(node: ts.Node) {
    // --- SAST-DANGEROUS-EVAL (CWE-95) ---
    if (isCallTo(node, "eval")) {
      findings.push({
        ruleId: "SAST-DANGEROUS-EVAL",
        name: "Uso de eval()",
        category: "Dangerous Functions",
        severity: "CRITICAL",
        cwe: "CWE-95",
        confidence: "high",
        file: fileName,
        line: getLine(sourceFile, node),
        snippet: node.getText().slice(0, 120),
        remediation: "Evite eval(). Use JSON.parse para dados, ou reestruture a lógica sem execução dinâmica de string.",
      });
    }

    // --- SAST-COMMAND-INJECTION (CWE-78) ---
    if (isCallTo(node, "exec", "execSync", "spawn")) {
      const firstArg = node.arguments[0];
      if (firstArg && isDynamicArg(firstArg)) {
        findings.push({
          ruleId: "SAST-COMMAND-INJECTION",
          name: "Possível Command Injection",
          category: "Injection",
          severity: "HIGH",
          cwe: "CWE-78",
          confidence: "medium",
          file: fileName,
          line: getLine(sourceFile, node),
          snippet: node.getText().slice(0, 160),
          remediation: "Use execFile/spawn com array de argumentos separados, nunca concatene entrada do usuário na string do comando.",
        });
      }
    }

    // --- SAST-WEAK-HASH (CWE-327) ---
    if (isCallTo(node, "createHash")) {
      const arg = node.arguments[0];
      if (arg && ts.isStringLiteralLike(arg) && /^(md5|sha1)$/i.test(arg.text)) {
        findings.push({
          ruleId: "SAST-WEAK-HASH",
          name: `Algoritmo de hash fraco (${arg.text})`,
          category: "Cryptography",
          severity: "HIGH",
          cwe: "CWE-327",
          confidence: "high",
          file: fileName,
          line: getLine(sourceFile, node),
          snippet: node.getText().slice(0, 120),
          remediation: "Use scrypt/argon2/bcrypt para senhas, ou SHA-256+ para integridade. Nunca MD5/SHA1 para dados sensíveis.",
        });
      }
    }

    // --- SAST-SQL-INJECTION (CWE-89) ---
    if (isCallTo(node, "query", "execute")) {
      const firstArg = node.arguments[0];
      if (firstArg && isDynamicArg(firstArg)) {
        // Heurística: só reporta se parecer SQL (contém SELECT/INSERT/UPDATE/DELETE)
        const textSample = node.getText();
        if (/\b(SELECT|INSERT|UPDATE|DELETE)\b/i.test(textSample)) {
          findings.push({
            ruleId: "SAST-SQL-INJECTION",
            name: "Possível SQL Injection por concatenação",
            category: "Injection",
            severity: "CRITICAL",
            cwe: "CWE-89",
            confidence: "medium",
            file: fileName,
            line: getLine(sourceFile, node),
            snippet: node.getText().slice(0, 160),
            remediation: "Use queries parametrizadas (?, $1, etc.) — nunca concatene ou faça template string com dados de entrada na query.",
          });
        }
      }
    }

    ts.forEachChild(node, visit);
  }

  visit(sourceFile);
  for (const finding of findings) { if (!getSecurityRule(finding.ruleId)) throw new Error(`Regra SAST sem registro: ${finding.ruleId}`); }
  return findings;
}
